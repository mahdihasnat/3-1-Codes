package service;

public enum ServiceType {
    WATER, POWER, TRANSPORT, TELECOM
}
