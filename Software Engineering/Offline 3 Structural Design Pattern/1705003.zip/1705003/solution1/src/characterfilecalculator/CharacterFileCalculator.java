package characterfilecalculator;

import java.io.IOException;

public interface CharacterFileCalculator {
     int calculateAsciiSum(String fileName) throws IOException;
}
