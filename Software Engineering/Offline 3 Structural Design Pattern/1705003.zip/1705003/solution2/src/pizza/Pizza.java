package src.pizza;

import src.food.Food;

public abstract class Pizza  implements Food {

}
