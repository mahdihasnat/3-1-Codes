package src.food;

public interface Food {
    int getPrice();
}
