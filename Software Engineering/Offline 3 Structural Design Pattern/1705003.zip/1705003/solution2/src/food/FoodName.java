package src.food;

public enum FoodName {
    VeggiePizza,
    BeefPizza,
    Coke,
    Coffee,
    OnionRings,
    FrenchFries
}
