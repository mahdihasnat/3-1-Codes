package main.server;

public class Spring implements Server {
    @Override
    public String toString() {
        return "Spring{}";
    }
}
