package main.server;

public class Laravel implements Server {
    @Override
    public String toString() {
        return "Laravel{}";
    }
}
