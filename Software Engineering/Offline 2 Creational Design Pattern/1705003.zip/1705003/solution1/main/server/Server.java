package main.server;

public interface Server {
}
