package main.server;

public class Django implements Server {
    @Override
    public String toString() {
        return "Django{}";
    }
}
