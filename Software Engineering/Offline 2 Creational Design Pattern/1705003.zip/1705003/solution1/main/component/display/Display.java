package main.component.display;

public interface Display {
    void print(String text);
}
