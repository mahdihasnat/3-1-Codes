package main.component.weightmeasurement;

public class LoadSensor implements WeightMeasurement {
    @Override
    public String toString() {
        return "LoadSensor{}";
    }
}
