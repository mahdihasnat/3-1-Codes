package main.component.weightmeasurement;

public interface WeightMeasurement {
}
