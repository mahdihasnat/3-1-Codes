package main.component.weightmeasurement;

public class WeightModule implements WeightMeasurement {
    @Override
    public String toString() {
        return "WeightModule{}";
    }
}
