package main.component.internet;

public class Ethernet implements Internet {
    @Override
    public String toString() {
        return "Ethernet{}";
    }
}
