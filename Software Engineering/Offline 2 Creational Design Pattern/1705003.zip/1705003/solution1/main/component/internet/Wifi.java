package main.component.internet;

public class Wifi implements Internet , WireLess {
    @Override
    public String toString() {
        return "Wifi{}";
    }
}
