package main.component.internet;

public interface Internet {
}
