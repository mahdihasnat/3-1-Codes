package main.component.internet;

public class Gsm implements Internet , WireLess {
    @Override
    public String toString() {
        return "Gsm{}";
    }
}
