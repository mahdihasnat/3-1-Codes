package main.component.identification;

public class NFC implements Identification {
    @Override
    public String toString() {
        return "NFC{}";
    }
}
