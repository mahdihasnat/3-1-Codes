package main.component.identification;

public class RFID implements Identification {
    @Override
    public String toString() {
        return "RFID{}";
    }
}
