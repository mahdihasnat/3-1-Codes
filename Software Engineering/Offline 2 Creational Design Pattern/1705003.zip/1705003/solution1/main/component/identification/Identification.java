package main.component.identification;

public interface Identification {

}
