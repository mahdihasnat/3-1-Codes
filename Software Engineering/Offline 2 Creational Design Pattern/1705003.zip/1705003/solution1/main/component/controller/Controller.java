package main.component.controller;

public interface Controller {
    String getInput();
}
