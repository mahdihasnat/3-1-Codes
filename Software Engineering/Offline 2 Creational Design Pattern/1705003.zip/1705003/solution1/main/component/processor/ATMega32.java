package main.component.processor;

public class ATMega32 implements Processor {
    @Override
    public String toString() {
        return "ATMega32{}";
    }
}
