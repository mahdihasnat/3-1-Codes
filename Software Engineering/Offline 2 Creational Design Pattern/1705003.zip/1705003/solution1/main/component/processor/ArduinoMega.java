package main.component.processor;

public class ArduinoMega implements Processor {
    @Override
    public String toString() {
        return "ArduinoMega{}";
    }
}
