package main.component.processor;

public interface Processor {

}
