package main.component.storage;

public interface Storage {
}
