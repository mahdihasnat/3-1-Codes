package main.component.storage;

public class SDCard implements Storage {
    @Override
    public String toString() {
        return "SDCard{}";
    }
}
