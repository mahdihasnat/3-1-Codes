package main.aesthetics.font;

public interface Font
{
    //Font properties goes here
}