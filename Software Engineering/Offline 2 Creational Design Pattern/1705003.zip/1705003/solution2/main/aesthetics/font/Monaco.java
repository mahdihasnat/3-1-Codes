package main.aesthetics.font;

public class Monaco implements Font {
    @Override
    public String toString() {
        return "Monaco{}";
    }
}