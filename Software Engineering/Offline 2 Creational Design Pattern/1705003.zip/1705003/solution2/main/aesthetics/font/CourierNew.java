package main.aesthetics.font;

public class CourierNew implements Font{
    public CourierNew() {
    }

    @Override
    public String toString() {
        return "CourierNew{}";
    }
}