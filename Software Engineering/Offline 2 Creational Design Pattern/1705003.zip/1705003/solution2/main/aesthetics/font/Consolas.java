package main.aesthetics.font;


public class Consolas implements Font {
    public Consolas() {
    }

    @Override
    public String toString() {
        return "Consolas{}";
    }
}