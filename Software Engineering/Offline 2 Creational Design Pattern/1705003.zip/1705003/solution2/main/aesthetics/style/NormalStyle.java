package main.aesthetics.style;

public class NormalStyle implements Style {
    public NormalStyle() {
    }

    @Override
    public String toString() {
        return "NormalStyle{}";
    }
}