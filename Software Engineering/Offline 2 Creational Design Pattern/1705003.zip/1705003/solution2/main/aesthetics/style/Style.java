package main.aesthetics.style;
public interface Style
{

}