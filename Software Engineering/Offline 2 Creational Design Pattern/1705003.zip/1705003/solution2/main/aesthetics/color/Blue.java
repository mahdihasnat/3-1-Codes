package main.aesthetics.color;

public class Blue implements Color {
    public Blue() {
    }

    @Override
    public String toString() {
        return "Blue{}";
    }
}
