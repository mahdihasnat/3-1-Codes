package main.aesthetics.color;

public interface Color {
}
